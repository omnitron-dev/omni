import type { State } from '../core/index.js';
import type { Readable, Writable } from 'node:stream';

import prism from '../prism/index.js';
import { settings } from '../core/index.js';
import isUnicodeSupported from '../core/utils/is-unicode-supported.js';

export const unicode = isUnicodeSupported();
export const isCI = (): boolean => process.env['CI'] === 'true';
export const isTTY = (output: Writable): boolean =>
  (output as Writable & { isTTY?: boolean }).isTTY === true;
export const unicodeOr = (c: string, fallback: string) => (unicode ? c : fallback);
export const S_STEP_ACTIVE = unicodeOr('◆', '*');
export const S_STEP_CANCEL = unicodeOr('■', 'x');
export const S_STEP_ERROR = unicodeOr('▲', 'x');
export const S_STEP_SUBMIT = unicodeOr('◇', 'o');

export const S_BAR_START = unicodeOr('┌', 'T');
export const S_BAR = unicodeOr('│', '|');
export const S_BAR_END = unicodeOr('└', '—');
export const S_BAR_START_RIGHT = unicodeOr('┐', 'T');
export const S_BAR_END_RIGHT = unicodeOr('┘', '—');

export const S_RADIO_ACTIVE = unicodeOr('●', '>');
export const S_RADIO_INACTIVE = unicodeOr('○', ' ');
export const S_CHECKBOX_ACTIVE = unicodeOr('◻', '[•]');
export const S_CHECKBOX_SELECTED = unicodeOr('◼', '[+]');
export const S_CHECKBOX_INACTIVE = unicodeOr('◻', '[ ]');
export const S_PASSWORD_MASK = unicodeOr('▪', '•');

export const S_BAR_H = unicodeOr('─', '-');
export const S_CORNER_TOP_RIGHT = unicodeOr('╮', '+');
export const S_CONNECT_LEFT = unicodeOr('├', '+');
export const S_CORNER_BOTTOM_RIGHT = unicodeOr('╯', '+');
export const S_CORNER_BOTTOM_LEFT = unicodeOr('╰', '+');
export const S_CORNER_TOP_LEFT = unicodeOr('╭', '+');

export const S_INFO = unicodeOr('●', '•');
export const S_SUCCESS = unicodeOr('◆', '*');
export const S_WARN = unicodeOr('▲', '!');
export const S_ERROR = unicodeOr('■', 'x');

export const symbol = (state: State) => {
  switch (state) {
    case 'initial':
    case 'active':
      return settings.theme.accent(S_STEP_ACTIVE);
    case 'cancel':
      return settings.theme.error(S_STEP_CANCEL);
    case 'error':
      return settings.theme.warning(S_STEP_ERROR);
    case 'submit':
      return settings.theme.success(S_STEP_SUBMIT);
    default:
      return prism.gray(S_STEP_ACTIVE);
  }
};

export const symbolBar = (state: State) => {
  switch (state) {
    case 'initial':
    case 'active':
      return settings.theme.accent(S_BAR);
    case 'cancel':
      return settings.theme.error(S_BAR);
    case 'error':
      return settings.theme.warning(S_BAR);
    case 'submit':
      return settings.theme.success(S_BAR);
    default:
      return prism.gray(S_BAR);
  }
};

export const computeLabel = (label: string, format: (text: string) => string): string => {
  if (!label.includes('\n')) {
    return format(label);
  }
  return label
    .split('\n')
    .map((line) => format(line))
    .join('\n');
};

export interface CommonOptions {
  input?: Readable;
  output?: Writable;
  signal?: AbortSignal;
  withGuide?: boolean;
}

/**
 * Renders the key-hint row shown below an option list, plus the closing bar
 * when the guide is on.
 *
 * The instruction strings stay plain; the muted role is applied here, at
 * render time, so a theme swapped via `updateSettings` reaches every frame.
 */
export function formatInstructionFooter(instructions: string[], hasGuide: boolean): string[] {
  const guidePrefix = hasGuide ? `${settings.theme.accent(S_BAR)}  ` : '';
  const footerLines = [`${guidePrefix}${settings.theme.muted(instructions.join(' • '))}`];
  if (hasGuide) {
    footerLines.push(settings.theme.accent(S_BAR_END));
  }
  return footerLines;
}
