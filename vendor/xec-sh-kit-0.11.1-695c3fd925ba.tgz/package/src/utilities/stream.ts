import type { LogMessageOptions } from './log.js';

import { stripVTControlCharacters as strip } from 'node:util';

import prism from '../prism/index.js';
import { settings } from '../core/index.js';
import { S_BAR, S_INFO, S_WARN, S_ERROR, S_SUCCESS, S_STEP_SUBMIT } from './common.js';

const prefix = `${prism.gray(S_BAR)}  `;

// TODO (43081j): this currently doesn't support custom `output` writables
// because we rely on `columns` existing (i.e. `process.stdout.columns).
//
// If we want to support `output` being passed in, we will need to use
// a condition like `if (output insance Writable)` to check if it has columns
export const stream = {
  message: async (
    iterable: Iterable<string> | AsyncIterable<string>,
    { symbol = prism.gray(S_BAR) }: LogMessageOptions = {}
  ) => {
    process.stdout.write(`${prism.gray(S_BAR)}\n${symbol}  `);
    let lineWidth = 3;
    for await (let chunk of iterable) {
      chunk = chunk.replace(/\n/g, `\n${prefix}`);
      if (chunk.includes('\n')) {
        lineWidth = 3 + strip(chunk.slice(chunk.lastIndexOf('\n'))).length;
      }
      const chunkLen = strip(chunk).length;
      if (lineWidth + chunkLen < process.stdout.columns) {
        lineWidth += chunkLen;
        process.stdout.write(chunk);
      } else {
        process.stdout.write(`\n${prefix}${chunk.trimStart()}`);
        lineWidth = 3 + strip(chunk.trimStart()).length;
      }
    }
    process.stdout.write('\n');
  },
  info: (iterable: Iterable<string> | AsyncIterable<string>) =>
    stream.message(iterable, { symbol: settings.theme.info(S_INFO) }),
  success: (iterable: Iterable<string> | AsyncIterable<string>) =>
    stream.message(iterable, { symbol: prism.green(S_SUCCESS) }),
  step: (iterable: Iterable<string> | AsyncIterable<string>) =>
    stream.message(iterable, { symbol: prism.green(S_STEP_SUBMIT) }),
  warn: (iterable: Iterable<string> | AsyncIterable<string>) =>
    stream.message(iterable, { symbol: prism.yellow(S_WARN) }),
  /** alias for `log.warn()`. */
  warning: (iterable: Iterable<string> | AsyncIterable<string>) => stream.warn(iterable),
  error: (iterable: Iterable<string> | AsyncIterable<string>) =>
    stream.message(iterable, { symbol: prism.red(S_ERROR) }),
};
